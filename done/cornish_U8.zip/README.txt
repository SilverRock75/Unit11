                             ______________

                                 README

                              John Cornish
                             ______________





1 URL
=====

  https://desolate-oasis-32353.herokuapp.com/


2 Notes
=======

  I separated my data into a data.js file to make it cleaner, so it
  won't look quite the same as other assignments you will be grading
  (I'm sorry!). It just seemed more sensible this way.
