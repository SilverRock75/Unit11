module.exports.courses = {
    'LSCI-427': {
        id: 'LSCI-427',
        title: 'Human centered humanity',
        instructor: 'J. Ames',
        credits: 3.0,
        blood: '100%',
        assignments: [
            {
                name: 'Unit 1 - Humans',
                due: '12/01/1999',
                points: 45,
                status: 'Not even on my radar',
            },
            {
                name: 'Unit 2 - Humanity',
                due: '12/01/2999',
                points: 47,
                status: 'Due date sounds vaguely soon',
            }
        ]
    },
    'CSCI-404': {
        id: 'CSCI-404',
        title: 'Course not found',
        instructor: 'E. Reerer',
        credits: 4.4,
        blood: '4ml',
        assignments: [],
    },
    'CSCCSSE-123': {
        id: 'CSCCSSE-123',
        title: 'Corporate Social Corporate-Centric Societal Structural Engineering',
        instructor: 'E. Sheer',
        credits: 1.5,
        blood: '0CC',
        assignments: [],
    },
}
