var data = require('../data');

module.exports = {
    courseInfo: function(req, res) {
        var course_id = req.params.course_id;
        var course_info = data.courses[course_id];

        res.render('course-info', course_info);
    },
    courseList: function(req, res) {
        var course_list = Object.values(data.courses);
        var render_data = {
            pageHeader: {
                title: 'Course Horse',
                strapline: 'Tired of screaming yourself hoarse? Reign in your assignments an stay on course with no remorse. Course horse, of course!',
            },
            courses: course_list,
        }

        res.render('courses-list', render_data);
    },
    addAssignment: function(req, res) {
        res.render('add-assignment', {course_id: req.params.course_id})
    }
}
